package com.jeofferson.onclas.PackageOthers;

public class Logos {

    public String banner = "https://firebasestorage.googleapis.com/v0/b/onclas-9415f.appspot.com/o/logo%2Fbanners.png?alt=media&token=63efa3a3-c8dd-44db-8518-09016fe40944";

}
